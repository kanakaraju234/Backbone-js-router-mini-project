var Tweet = Backbone.Model.extend({
    defaults: function(){
        return{
            author:'A',
            status:''
        }
    }
})
var TweetList = Backbone.Collection.extend({
    model:Tweet
})
var tweets = new TweetList()
/*for view*/

var TweetView = Backbone.View.extend({
    model: new Tweet(),
     template:_.template($('#tweet-template').html()),
    tagName:'div',
   
    render:function(){
        this.$el.html(this.template(this.model.toJSON()));
        return this
    }
}) 

var TweetsView= Backbone.View.extend({
    model:tweets,
    el:$('#tweets-container'),
    initialize:function(){
      this.model.on('add', this.render, this)  
    },
    render:function(){
         var self = this;
        self.$el.html('')
     _.each(this.model.toArray(),function(tweet){
            self.$el.append((new TweetView({model:tweet})).render().$el)
        })
        return this
    }
})
$(document).ready(function(){
    $('#new-tweet').submit(function(ev){
       var tweet = new Tweet({author:$('#author-name').val(), status:$('#status-update').val()})
  tweets.add(tweet)
console.log(tweets.toJSON())  
    return false   
    })
var appView = new TweetsView();
})
